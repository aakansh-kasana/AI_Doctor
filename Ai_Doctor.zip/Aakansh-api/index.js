// index.js
const express = require('express');
const OpenAI = require('openai');
const bodyParser = require('body-parser');
const path = require('path');

const app = express();

// Initialize OpenAI API with your API key
const openai = new OpenAI({
  apiKey: "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",
});

// Middleware to serve static files and parse request bodies
app.use(express.static(path.join(__dirname, 'public')));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// Serve the main HTML page
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'views', 'index.html'));
});

// Endpoint to handle OpenAI requests
app.post('/get-response', async (req, res) => {
  const { prompt } = req.body;
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4",
      messages: [{ role: "user", content: prompt }],
    });
    
    // Formatting the response message in HTML
    const formattedMessage = response.choices[0].message.content
      .replace(/\*\*(.*?)\*\*/g, "<strong>$1</strong>") // Bold
      .replace(/\d+\.\s/g, "<br><strong>$&</strong>") // Numbered List
      .replace(/(•\s)/g, "<ul><li>$1</li></ul>"); // Bullet Points

    res.json({ message: formattedMessage.trim() });
  } catch (error) {
    console.error("Error with the OpenAI API:", error.message);
    res.status(500).send("Error processing the request.");
  }
});

// Start the server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
